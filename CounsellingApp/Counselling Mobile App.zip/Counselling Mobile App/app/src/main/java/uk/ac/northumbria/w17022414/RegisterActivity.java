package uk.ac.northumbria.w17022414;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static uk.ac.northumbria.w17022414.LoginActivity.db;

public class RegisterActivity extends AppCompatActivity {

    private TextView GoBackButton;

    private Spinner  UserType;
    private EditText EmailTxt;
    private EditText PassTxt;
    private Spinner  TitleTxt;
    private EditText FNameTxt;
    private EditText LNameTxt;
    final Calendar myCalendar = Calendar.getInstance();
    private EditText DOBTxt;
    private EditText PhoneNoTxt;
    private TextView ExtLabel;
    private EditText ExtText;

    private Button SubmitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        UserType = findViewById(R.id.spn_regUserType);
        ArrayAdapter<CharSequence> cusTypeAdapter = ArrayAdapter.createFromResource(this,
                R.array.userType, android.R.layout.simple_spinner_item);
        cusTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        UserType.setAdapter(cusTypeAdapter);

        UserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if(UserType.getSelectedItem().toString().equals("Client")) {
                    ExtLabel.setText(R.string.NHSNo);
                    ExtText.setHint(R.string.promptNHSNo);
                }
                else {
                    ExtLabel.setText(R.string.EmployeeNo);
                    ExtText.setHint(R.string.promptEmployeeNo);
                }
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        TitleTxt = findViewById(R.id.spn_regTitle);
        ArrayAdapter<CharSequence> titleAdapter = ArrayAdapter.createFromResource(this,
                R.array.titles, android.R.layout.simple_spinner_item);
        titleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        TitleTxt.setAdapter(titleAdapter);

        EmailTxt   = findViewById(R.id.txt_regEmail);
        PassTxt    = findViewById(R.id.txt_logPassword);
        FNameTxt   = findViewById(R.id.txt_regFirstName);
        LNameTxt   = findViewById(R.id.txt_regLastName);
        DOBTxt     = findViewById(R.id.txt_regDOB);
        PhoneNoTxt = findViewById(R.id.txt_regPhoneNo);
        ExtLabel   = findViewById(R.id.lbl_externalNo);
        ExtText    = findViewById(R.id.txt_regExternalNo);

        final DatePickerDialog.OnDateSetListener userDOB = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        DOBTxt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(RegisterActivity.this, userDOB, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        SubmitBtn  = findViewById(R.id.btn_submit);

        SubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userType = UserType.getSelectedItem().toString();
                String email    = EmailTxt.getText().toString();
                String password = PassTxt.getText().toString();
                String title    = TitleTxt.getSelectedItem().toString();
                String fName    = FNameTxt.getText().toString();
                String lName    = LNameTxt.getText().toString();
                String DOB      = DOBTxt.getText().toString();
                String phoneNo  = PhoneNoTxt.getText().toString();
                String external = ExtText.getText().toString();

                if((email.isEmpty()) || (fName.isEmpty()) || (lName.isEmpty()
                ) || (DOB.isEmpty()) || (phoneNo.isEmpty()) || (external.isEmpty())) {
                    Toast.makeText(RegisterActivity.this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
                }
                else {
                    // Instantiate New User //

                    db.getWritableDatabase();
                    db.insertIntoUsers(userType, email, password, title, fName, lName, DOB, phoneNo);

                    Toast.makeText(RegisterActivity.this, "Account Successfully Created!", Toast.LENGTH_SHORT).show();


                    Intent intent = new Intent(RegisterActivity.this, MainMenu.class);
                    intent.putExtra("EMAIL", email);
                    startActivity(intent);
                }
            }
        });
    }

    private void updateLabel() {
        String myFormat = "dd/MM/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.UK);

        DOBTxt.setText(sdf.format(myCalendar.getTime()));
    }


}