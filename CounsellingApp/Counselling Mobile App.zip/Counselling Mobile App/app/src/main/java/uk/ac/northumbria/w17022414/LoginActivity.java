package uk.ac.northumbria.w17022414;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    static DatabaseHelper db;

    private EditText EmailText;
    private EditText PasswordText;
    private Button LoginButton;
    private TextView RegisterLbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);
//        db.getWritableDatabase();



        EmailText    = findViewById(R.id.txt_logEmail);
        PasswordText = findViewById(R.id.txt_logPassword);
        LoginButton  = findViewById(R.id.btn_login);
        RegisterLbl  = findViewById(R.id.lbl_registerText);

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    String email    = EmailText.getText().toString();
                    String password = PasswordText.getText().toString();

                    if(!((email.isEmpty()) || (password.isEmpty()))) {
                        if(validateLogin(email, password)) {
                            Toast.makeText(LoginActivity.this, "Successfully Logged-In!!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(LoginActivity.this, MainMenu.class));
                        }
                        else {
                            Toast.makeText(LoginActivity.this, "Please fill in the correct information.",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(LoginActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                    }
            }
        });

        RegisterLbl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(LoginActivity.this, RegisterActivity.class)));
            }
        });
    }

    private Boolean validateLogin(String email, String password) {
        db.getWritableDatabase();

        Cursor result = db.getSingleUserData(email);
        if (result.getCount() == 0) {
            return false;
        }
        else if (result.getCount() == 1){
            //StringBuffer buf = new StringBuffer();
            result.moveToFirst();
            String resEmail = result.getString(2);
            String resPass  = result.getString(3);

            if (email.equals(resEmail) && password.equals(resPass)) {
                String resFName = result.getString(5);
                String resLName = result.getString(6);
                Toast.makeText(this, "Welcome " + resFName + " " + resLName + "!", Toast.LENGTH_SHORT).show();

                return true;
            }
            else {
                Toast.makeText(this, "Sorry, wrong password.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else {
            Toast.makeText(this, "Error, contact an administrator.", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

}
