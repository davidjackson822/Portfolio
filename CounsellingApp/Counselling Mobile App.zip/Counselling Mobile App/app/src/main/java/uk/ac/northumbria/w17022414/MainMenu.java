package uk.ac.northumbria.w17022414;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


//

// Make a UML diagram

// Make a Bookings class that holds individual bookings

// Complete make_booking_activity design
// Complete timetable_day design

public class MainMenu extends AppCompatActivity {

    String currentUserEmail;

    public Button btn_SignOut;
    public Button btn_MakeABooking;
    public Button btn_ViewProfile;
    public Button btn_ViewBookings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Intent getEmail = getIntent();
        currentUserEmail = getEmail.getStringExtra("EMAIL");


        btn_SignOut = findViewById(R.id.btn_SignOut);
        btn_MakeABooking = findViewById(R.id.btn_MakeBooking);
        btn_ViewProfile = findViewById(R.id.btn_ViewProfile);
        btn_ViewBookings = findViewById(R.id.btn_ViewBookings);

    }

    public void onClick(View v){
        if (btn_SignOut.equals(v)) {
            startActivity(new Intent(this, LoginActivity.class).putExtra("EMAIL", currentUserEmail ));
        } else if (btn_MakeABooking.equals(v)) {
            startActivity(new Intent(this, MakeBookingActivity.class).putExtra("EMAIL", currentUserEmail));
        } else if (btn_ViewProfile.equals(v)) {
            startActivity(new Intent(this, AccountDetails.class).putExtra("EMAIL", currentUserEmail));
        } else if (btn_ViewBookings.equals(v)) {
            startActivity(new Intent(this, TimetableMonth.class).putExtra("EMAIL", currentUserEmail));
        } else {
            startActivity(new Intent(this, AccountDetails.class).putExtra("EMAIL", currentUserEmail));
        }
    }
}
