package uk.ac.northumbria.w17022414;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "YourCounselling.db";

    private final String TABLE_USERS = "Users";
    private final String USER_COL_1 = "UserID";
    private final String USER_COL_2 = "UserType";
    private final String USER_COL_3 = "Email";
    private final String USER_COL_4 = "Password";
    private final String USER_COL_5 = "Title";
    private final String USER_COL_6 = "FirstName";
    private final String USER_COL_7 = "LastName";
    private final String USER_COL_8 = "DOB";
    private final String USER_COL_9 = "PhoneNo";


    private final String TABLE_BOOKINGS = "Bookings";
    private final String BOOK_COL_1 = "BookID";
    private final String BOOK_COL_2 = "ClientID";
    private final String BOOK_COL_3 = "CounsellorID";
    private final String BOOK_COL_4 = "Date";
    private final String BOOK_COL_5 = "Duration";




    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create_userDB = "create table " + TABLE_USERS +
                " (" + USER_COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_COL_2 + " TEXT, "
                + USER_COL_3 + " TEXT, "
                + USER_COL_4 + " TEXT, "
                + USER_COL_5 + " TEXT, "
                + USER_COL_6 + " TEXT, "
                + USER_COL_7 + " TEXT, "
                + USER_COL_8 + " DATE, "
                + USER_COL_9 + " TEXT) ";
        db.execSQL(create_userDB);

        String create_bookingDB = "create table " + TABLE_BOOKINGS +
                " (" + BOOK_COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + BOOK_COL_2 + " INTEGER, "
                + BOOK_COL_3 + " INTEGER, "
                + BOOK_COL_4 + " DATE, "
                + BOOK_COL_5 + " TEXT)";

        db.execSQL(create_bookingDB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String drop_users = "DROP TABLE IF EXISTS " + TABLE_USERS;
        db.execSQL(drop_users);

        String drop_bookings = "DROP TABLE IF EXISTS " + TABLE_BOOKINGS;
        db.execSQL(drop_bookings);
    }

    public boolean insertIntoUsers(String userType, String email, String password,
                                   String title, String fName, String lName,
                                   String DOB, String phoneNo) {


        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_2, userType);
        contentValues.put(USER_COL_3, email);
        contentValues.put(USER_COL_4, password);
        contentValues.put(USER_COL_5, title);
        contentValues.put(USER_COL_6, fName);
        contentValues.put(USER_COL_7, lName);
        contentValues.put(USER_COL_8, DOB);
        contentValues.put(USER_COL_9, phoneNo);

        long res = db.insert(TABLE_USERS, null, contentValues);
        return res != -1;

    }

    public boolean insertIntoBookings(/* UNFINISHED */) {
        SQLiteDatabase db = this.getWritableDatabase();



        return false;
    }

    public Cursor getAllUserData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String retrieveInfoSQL = "SELECT * FROM " + TABLE_USERS;

        return db.rawQuery(retrieveInfoSQL, null);
    }

    Cursor getAllCounsellorNames() {
        SQLiteDatabase db = this.getWritableDatabase();
        String retrieveAllCounsellors = "SELECT UserID, FirstName, LastName from Users where UserType = 'Counsellor'";
        Cursor result = db.rawQuery(retrieveAllCounsellors, null);

        return result;
    }

    Cursor getSingleUserData(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        String retrieveSingleUser = "SELECT * FROM " + TABLE_USERS + " WHERE email = '" + email + "'";
        Cursor result = db.rawQuery(retrieveSingleUser, null);

        return result;
    }



}
