package uk.ac.northumbria.w17022414;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static uk.ac.northumbria.w17022414.LoginActivity.db;

public class MakeBookingActivity extends AppCompatActivity {

    private String currentUserEmail;
    public Calendar BookCalendar = Calendar.getInstance();

    private Spinner BookCounsellor;
    private EditText BookDate;
    private Spinner BookTime;
    private Spinner BookDuration;
    private Button BookSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_booking_activity);

        Intent getEmail = getIntent();
        currentUserEmail = getEmail.getStringExtra("EMAIL");

        BookCounsellor = findViewById(R.id.spn_BookCounsellor);
        BookDate = findViewById(R.id.txt_BookDate);
        BookTime = findViewById(R.id.spn_BookTime);
        BookTime = findViewById(R.id.spn_BookTime);

        final String[][] currentCounsellors = getCounsellors();
        int size = currentCounsellors.length;
        String[] currentCounsellorsArray = new String[size];

        for(int i = 0; i < size; i++) {
            currentCounsellorsArray[i] = currentCounsellors[i][1] + " " + currentCounsellors[i][2];
        }

        // Populate the Counsellor Spinner
        ArrayAdapter<String> counsellorAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, currentCounsellorsArray);

        counsellorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        BookCounsellor.setAdapter(counsellorAdapter);

        // Set the date to popup a calendar
        final DatePickerDialog.OnDateSetListener bookDateListener = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                BookCalendar.set(Calendar.YEAR, year);
                BookCalendar.set(Calendar.MONTH, monthOfYear);
                BookCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        BookDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(MakeBookingActivity.this, bookDateListener, BookCalendar
                        .get(Calendar.YEAR), BookCalendar.get(Calendar.MONTH),
                        BookCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Populate the time spinner
        ArrayAdapter<CharSequence> timeAdapter = ArrayAdapter.createFromResource(this,
                R.array.Times, android.R.layout.simple_spinner_item);
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        BookTime.setAdapter(timeAdapter);

        // populate the duration spinner
        ArrayAdapter<CharSequence> durationAdapter = ArrayAdapter.createFromResource(this,
                R.array.Durations, android.R.layout.simple_spinner_item);
        durationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        BookDuration.setAdapter(durationAdapter);


        BookSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor currentUser = db.getSingleUserData(currentUserEmail);
                currentUser.moveToFirst();

                String currentUserID = currentUser.getString(0);

                int counsellorInt = BookCounsellor.getSelectedItemPosition();
                String counsellorID = currentCounsellors[counsellorInt][0];
                String bookDate = BookDate.getText().toString();
                String bookTime = BookTime.getSelectedItem().toString();
                String bookDuration = BookDuration.getSelectedItem().toString();


            }
        });
    }

    private String[][] getCounsellors() {
        //db.getWritableDatabase();

        Cursor counsellors = db.getAllCounsellorNames();
        int size = counsellors.getCount();
        String[][] results = new String[size][3];


        if(size > 0) {
            int i = 0;
            while (counsellors.moveToNext()) {
                results[i][0] = counsellors.getString(0);
                results[i][1] = counsellors.getString(1);
                results[i][2] = counsellors.getString(2);
                i++;
            }
        }
        else
            Toast.makeText(this, "No Counsellors Found!", Toast.LENGTH_LONG).show();
        return results;

    }

    private void updateLabel() {
        String myFormat = "dd/MM/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.UK);

        BookDate.setText(sdf.format(BookCalendar.getTime()));
    }
}
