package uk.ac.northumbria.w17022414;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AccountDetails extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_account_details);
    }

}
