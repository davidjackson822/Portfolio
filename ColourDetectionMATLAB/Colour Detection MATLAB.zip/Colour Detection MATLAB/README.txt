README

For MATLAB R2020
(Should work on MATLAB R2019)

Double click on UIColourDetectionApplication.mlapp
To start the GUI, click run or f5.

The TrainingColours.mat file is the training data for the algorithm.
The SVMTrained is the Machine Learning algorithm that used the training data.
ColourMap is what the value for each colour class means.
Colours is a folder that contains some images for testing use.

By David Jackson w17022414